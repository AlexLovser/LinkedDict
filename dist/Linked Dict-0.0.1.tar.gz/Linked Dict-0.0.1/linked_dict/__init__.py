"""
:authors: Alex Lovser
:licence: Apache Licence, Version 2.0, see LICENCE file

:copyright: (c) 2022 Alex Lovser
"""

from .linked_dict import LinkedDict

__author__ = 'Alex Lovser'
__version__ = '0.0.1'
__email__ = 'tabalex2005@gmail.com'
